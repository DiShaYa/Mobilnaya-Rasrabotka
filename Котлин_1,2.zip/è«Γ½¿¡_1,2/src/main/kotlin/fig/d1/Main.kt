package fig.d1

fun main(args: Array<String>) {
    println("Program arguments: ${args.joinToString()}")
    main()
    circle()
}