package fig.d1

import java.util.Scanner
fun circle(){
    var radius = 9
    println("Окружность радиусом = " + radius)
    val scan = Scanner(System.`in`)     // Использ сканнера для ввода чисел
    println("Введите координаты точки x: ")
    val x = scan.nextInt()
    print("Введите координаты точки у: ")
    val y = scan.nextInt()
    if (x <= radius && y <= radius && x >= -radius && y >= -radius){
        print("Точка входит в окружность")
    }
    else
        print("Точка не входит в окружность")
}