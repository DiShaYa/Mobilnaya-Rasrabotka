package fig.d1

import java.util.Scanner

fun main(){
    val scan = Scanner(System.`in`)     // Использ сканнера для ввода чисел
    print("Введите сторону 1:")
    val a = scan.nextInt()              //вводим стороны треугольника

    print("Введите сторону 2:")
    val b = scan.nextInt()

    print("Введите сторону 3:")
    val c = scan.nextInt()
    var sum1 = 0                        //Обьявляем переменные стороны треугольника
    sum1 = a+b
    var sum2: Int = 0
    sum2 = a+c
    var sum3: Int = 0
    sum3 = b+c

    var max: Int = 0          //Обьвялеем квадраты сторон и находим большую сторону
    var min1: Int = 0
    var min2: Int = 0
    if (a>b && a >c)
        max = a*a
    min1 = b*b
    min2 = c*c
    if (b>a && b>c)
        max= b*b
    min1 = a*a
    min2 = c*c
    if (c>a && c>b)
        max = c*c
    min1 = b*b
    min2 = a*a

    if(sum1 > c && sum2>b && sum3 > a) {   //Условие проверки
        println("Треугольник существует")
        if (a == b || a == c || c == b) {
            println("Он Равнобедренный")
            when{
                (max == min1 + min2) -> println("Он Прямоугольный")
                (max > min1 + min2) -> println("Он Тупоугольный")
                (max < min1 + min2) -> println("Он Остроугольный")
            }
        }
        else
            println("Он не равнобедренный")
        if( a == b && b == c )
            println("Он равносторонний")
        else
            println("Он не равносторонний")
    }
    else
        println("Такого треугольника не существует")
}